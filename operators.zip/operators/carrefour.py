import sys
import os

import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, StaleElementReferenceException
from selenium.webdriver.common.keys import Keys
import pickle
import time
from math import sin, cos, pi
from time import sleep



import warnings
warnings.filterwarnings("ignore")

from seleniumbase import Driver
driver = Driver(uc=True)
output_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "output"))
sys.path.append(output_path)
output = os.path.join(output_path, "Carrefour.xlsx")

csv_file_path = os.path.join(output_path, "Carrefour1.csv")

from helper_functions import *


my_logger = logger_func(log_file=log_file)




# ***************CARREFOUR******************



if __name__ == "__main__":
    try:

        category_dict = {
        # "https://www.carrefour.ke/mafken/en/c/FKEN1660000": "Fruits & Vegetables", # not working
    
        
        
        "https://www.carrefour.ke/mafken/en/c/FKEN1714000": "Food Cupboard",
        "https://www.carrefour.ke/mafken/en/c/FKEN1760000": "Food Cupboard",
        "https://www.carrefour.ke/mafken/en/c/FKEN1740000": "Food Cupboard",
        "https://www.carrefour.ke/mafken/en/c/FKEN1710000": "Food Cupboard",
        "https://www.carrefour.ke/mafken/en/c/FKEN1730000": "Food Cupboard",
        "https://www.carrefour.ke/mafken/en/c/FKEN1701200": "Food Cupboard",
        "https://www.carrefour.ke/mafken/en/c/FKEN1701300": "Food Cupboard",

        "https://www.carrefour.ke/mafken/en/c/FKEN1520000": "Beverages",
        "https://www.carrefour.ke/mafken/en/c/FKEN1560000": "Beverages",
        "https://www.carrefour.ke/mafken/en/c/FKEN1550000": "Beverages",
        "https://www.carrefour.ke/mafken/en/c/FKEN1510000": "Beverages",
        "https://www.carrefour.ke/mafken/en/c/FKEN1570000": "Beverages",
        "https://www.carrefour.ke/mafken/en/c/FKEN1540000": "Beverages",
        "https://www.carrefour.ke/mafken/en/c/FKEN1530000": "Beverages",

        "https://www.carrefour.ke/mafken/en/c/FKEN6000000": "Frozen Food",

        "https://www.carrefour.ke/mafken/en/c/FKEN1610000": "Bakery",
   
        "https://www.carrefour.ke/mafken/en/c/FKEN1200000": "Bio & Organic Food",

        "https://www.carrefour.ke/mafken/en/c/NFKEN9000000": "Kiosk",

        "https://www.carrefour.ke/mafken/en/c/NFKEN3020000": "Cleaning Supplies",

        "https://www.carrefour.ke/mafken/en/c/NFKEN3080000": "Laundry & Detergents",

        "https://www.carrefour.ke/mafken/en/c/NFKEN3100000": "Kitechen & Toilet Rolls",

        "https://www.carrefour.ke/mafken/en/c/NFKEN3030000": "Disposables Tableware & Napkins",

        "https://www.carrefour.ke/mafken/en/c/FKEN1600000": "Fresh Food",

        "https://www.carrefour.ke/mafken/en/c/NFKEN3090000": "Tissues"



        }

        carrefour = extract_carrefour_data(driver, category_dict, csv_file_path)
        
        # carrefour = pd.read_csv(csv_file_path)

        my_logger.info(f"Webscraping successful. Extracted {len(carrefour)} products from Carrefour")

        merged_carrefour = merge_template(df=carrefour, left_on="Carrefour Product Name", right_on="Product", website="Carrefour" )

        merged_carrefour.to_excel(output, index=False)

    except Exception as e:
        my_logger.info(f"Error: {str(e)}")