import sys
import os

import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, StaleElementReferenceException
from selenium.webdriver.common.keys import Keys
import pickle
import undetected_chromedriver as uc



import warnings
warnings.filterwarnings("ignore")
from seleniumbase import Driver
driver = Driver(
    # headed=True, 
    uc=True, 
    undetectable=True,
    # no_sandbox=True
)



output_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "output"))
sys.path.append(output_path)
output = os.path.join(output_path, "Naivas.xlsx")

output1 = os.path.join(output_path, "Naivas_raw.xlsx")



from helper_functions import  *


my_logger = logger_func(log_file=log_file)


if __name__ == "__main__":

    all_elements = {
        "Food Cupboard": "https://naivas.online/food-cupboard",
        "Cleaning": "https://naivas.online/cleaning",
        "Fresh Food": "https://naivas.online/fresh-food",
        
        }

    try:
        naivas = extract_naivas_data(driver, all_elements)

        naivas.to_excel(output1, index=False)


        my_logger.info(f"Webscraping successful. Extracted {len(naivas)} products from Naivas")

        merged_naivas = merge_template(df=naivas, left_on="Naivas Product Name", right_on="Product", website="Naivas" )

        merged_naivas.to_excel(output, index=False)

    except Exception as e:
        my_logger.info(f"Error: {str(e)}")

