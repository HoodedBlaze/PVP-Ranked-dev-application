import sys
import os

import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, StaleElementReferenceException
from selenium.webdriver.common.keys import Keys


import warnings
warnings.filterwarnings("ignore")
from seleniumbase import Driver
driver = Driver(uc=True)

output_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "output"))
sys.path.append(output_path)
output = os.path.join(output_path, "Jumia.xlsx")


from helper_functions import *


my_logger = logger_func(log_file=log_file)

# *************JUMIA***********************
if __name__ == "__main__":
    try:
       
        jumia = extract_jumia_data()

        my_logger.info(f"Webscraping successful. Extracted {len(jumia)} products from Jumia")
        
        jumia.rename({"category": "Category", "name": "Product", "price": "Price", "link": "Link"}, axis=1, inplace=True)

        merged_jumia = merge_template(df=jumia, left_on="Jumia Product Name", right_on="Product", website="Jumia")

        merged_jumia.to_excel(output, index=False)

    except Exception as e:
        my_logger.info(f"Error: {str(e)}")