import os
import sys

import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException, StaleElementReferenceException
from selenium.common.exceptions import NoSuchElementException
import time
from math import sin, cos, pi
from time import sleep

from selenium.webdriver.common.keys import Keys
import time
import re
import numpy as np
import jellyfish as jf
from fuzzywuzzy import fuzz
from fuzzywuzzy import process

import datetime
import requests
from bs4 import BeautifulSoup

import pickle
import warnings
warnings.filterwarnings("ignore")
import logging 




data_path = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "data"))
sys.path.append(data_path)
matches_path = os.path.join(data_path, "matches.xlsx")
output_path = os.path.join(data_path, "output.xlsx")

# Configure logger

today = datetime.datetime.now()
day = today.day
month = today.month
year = today.year
logs_file = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "logs"))
sys.path.append(logs_file)
log_file = os.path.join(logs_file, f"foodstuff_logs_{day}_{month}_{year}.log" )

def logger_func(log_file):
    
    # Configure logging to create a logger instance
    logger = logging.getLogger('foodstuff_logger')
    logger.setLevel(logging.INFO)  

    # Create a console handler and set the log level for it
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)  

    # Create a file handler and set the log level for it
    file_handler = logging.FileHandler(log_file)  
    file_handler.setLevel(logging.INFO) 

    # Create a formatter and attach it to the handlers
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    console_handler.setFormatter(formatter)
    file_handler.setFormatter(formatter)

    # Attach the handlers to the logger
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    
    return logger

my_logger = logger_func(log_file=log_file)



def merge_template(df, left_on, right_on, website):
    matches = pd.read_excel(matches_path, sheet_name="Sheet2")
    template  = pd.read_excel(output_path, sheet_name="Daily", skiprows=1)
    template = template[['Code', 'Product description', 'Category - (1)', 'Category - (2)',
       'Private Label ', 'Private Label Only']]
    merged_df = pd.merge(matches, df[['Product', "Price"]], how="inner", left_on=left_on, right_on=right_on)
    merged_df = merged_df[['Copia Product Code','Price']]
    merged_df.columns = ['Copia Product Code', f"{website}"]
    template = pd.merge(template, merged_df, left_on = "Code", right_on = "Copia Product Code", how="left" )
    return template



# ******************JUMIA*********************

def get_all_category():
    

    try:
        cat_url = "https://www.jumia.co.ke/fragment/fly-out/?lang=en"

        html_response = requests.get(cat_url)
        html = html_response.text

        soup = BeautifulSoup(html)
        main_categories = []
        all_elements = {}

        for link in soup.find_all("a", attrs={"class": "itm"}, href=True):
            all_elements = {}
            all_elements['name'] = link.find("span").text
            all_elements['link'] = link['href']
            main_categories.append(all_elements)

        return main_categories
    except Exception as e:
        my_logger.info(e)

        

def extract_category(all_elements):

    try:
        categories = []
        

        is_sub_cat = False
        temp = {}

        for elements in all_elements:
            if is_sub_cat:
                temp["data"] = []

                sub_divs = elements.findAll("div", attrs={"class": "cat"})
    except Exception as e:
        my_logger.info(e)
                



def get_products(category_name, category_link):
    total_pages = None
    current_page = 1
    products = []

    current_date = datetime.datetime.now()
    try:

        while current_page == 1 or total_pages >= current_page:
            
            if 'https' in category_link:
                url = category_link + "?page=" +str(current_page)
            else:
                url = "https://www.jumia.co.ke" + category_link + "?page=" + str(current_page)
            # my_logger.info("URL : %s", url)


            html_response = requests.get(url)
            html = html_response.text

            soup = BeautifulSoup(html)

            if total_pages is None:
                href = soup.find("a", attrs={"class": "pg", "aria-label": "Last Page"}).attrs['href']
                regex_match = re.search("(?!=\/?page)(\d{1,4})(?=#catalog-listing)", href)
                total_pages = int(regex_match.group())
            
            for product in soup.find_all('div', attrs={'class':'info'}):
                value = {}
                if product.find('h3').text:
                    value['category'] = category_name
                    value['name'] =product.find('h3').text
                    value['price'] =product.find('div', attrs={'class': 'prc'}).text
                    
                    value['link'] ="https://www.jumia.co.ke" + product.parent['href']
                    products.append(value)
            current_page += 1
        return products
        
    except Exception as e:
        my_logger.info(e)


pre_defined_category = [{'name': 'Food Cupboard', 'link': '/food-cupboard-supplies/'}]

def extract_jumia_data():
    

    try:
        categories = None

        if pre_defined_category is not None:
            
            categories = pre_defined_category
        else:
            
            categories = get_all_category()

        

        if type(categories) != type(list()):
            raise Exception('Failed to get Categories')
        
        product_groups = []
        i = 0
        for sub_categories in categories:
            my_logger.info(f"Started for Category: {sub_categories['name']}")

            products = get_products(sub_categories['name'], sub_categories['link'])
            product_groups.extend(products)
            i += 1
            if i >= 1:
                

                df = pd.DataFrame(data=product_groups)

        return df
            
    except Exception as e:
        my_logger.info(e)







# *************************NAIVAS*******************************

def scroll_to_end_naivas(driver):
    while True:
        # Get the initial scroll height
        initial_scroll_height = driver.execute_script("return document.body.scrollHeight")

        # Scroll to the bottom of the page
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")

        # Wait for some time for the page to load
        sleep(5)

        # Get the new scroll height after waiting for 15 seconds
        new_scroll_height = driver.execute_script("return document.body.scrollHeight")

        # If the scroll height remains the same, break the loop
        if new_scroll_height == initial_scroll_height:
            break




def extract_naivas_data(driver,all_elements):
    products = []
    for k, v in all_elements.items():
        my_logger.info(v)
        url = v
        category = k
        driver.get(url)
        scroll_to_end_naivas(driver)

        soup=BeautifulSoup(driver.page_source,"html.parser")
        time.sleep(5)

        # product_lists = driver.find_elements(By.CLASS_NAME,"product-list")
        product_lists = soup.find_all("div", attrs={"class":"product-list"})
        time.sleep(5)
        for list in product_lists:
            product_elements = list.find_all("div", attrs={"class":"second-third-block"})
            time.sleep(5)
            for element in product_elements:
                
                product = element.find("h5", attrs={"class":"product-name"}).text.strip()

                link = element.find("a", href = True).get('href')

                try:
                    price = element.find("span", attrs={"class":"product-price"}).text.strip()
                except:
                    price = None
                
                products.append((product,category,price,link))

        my_logger.info(f"Extracted {len(products)} so far!!")
                


    return pd.DataFrame(products, columns=['Product', 'Category',  'Price', 'Link'])





# **********************************CARREFOUR************************************




def scroll_to_end(driver):
    while True:
        # Scroll to the bottom of the page
        driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
        try:
            load_more_button = WebDriverWait(driver, 10).until(
                EC.visibility_of_element_located((By.CSS_SELECTOR, "button[data-testid='trolly-button']"))
            )
            load_more_button.click()
        except:
            break

        # Wait for some time for the page to load
        sleep(10)  # Adjust the sleep duration as needed


def ease_out(t):
    return sin(t * (pi / 2))

def scroll_to_top(driver):
    page_height = driver.execute_script("return document.body.scrollHeight;")
    duration = 60.0  # Adjust this value to control the scroll speed

    start_time = time.time()
    while time.time() - start_time <= duration:
        elapsed_time = time.time() - start_time
        t = elapsed_time / duration
        scroll_position = page_height * (1 - ease_out(t))
        driver.execute_script("window.scrollTo(0, arguments[0]);", scroll_position)
        sleep(0.05)  # Adjust this value to control the smoothness of the scroll

    # Scroll to the top position to ensure accuracy
    driver.execute_script("window.scrollTo(0, 0);")



def scroll_to_bottom(driver):
    current_position = driver.execute_script("return window.pageYOffset;")
    page_height = driver.execute_script("return document.body.scrollHeight;")
    duration = 60.0  # Adjust this value to control the scroll speed

    start_time = time.time()
    while time.time() - start_time <= duration:
        elapsed_time = time.time() - start_time
        t = elapsed_time / duration
        scroll_position = current_position + (page_height - current_position) * ease_out(t)
        driver.execute_script("window.scrollTo(0, arguments[0]);", scroll_position)
        sleep(0.05)  # Adjust this value to control the smoothness of the scroll

    # Scroll to the bottom position to ensure accuracy
    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")



def extract_carrefour_data(driver, category_dict):
    products = []
    for key, value in category_dict.items():
        my_logger.info(value)
        url = key
        category = value
        driver.get(url)

        try:
            scroll_to_end(driver)
            scroll_to_top(driver)
            scroll_to_bottom(driver)

        except Exception as e:
            my_logger.info(f"Exception: {str(e)}")

        product_rows = driver.find_elements(By.CLASS_NAME, "css-5kig18")
        

        for row in product_rows:
            product_elements = row.find_elements(By.CLASS_NAME, "css-b9nx4o")
            for element in product_elements:
                # Extract product name
                product = element.find_element(By.CLASS_NAME, "css-tuzc44").text.strip()

                # Extract product price
                price = element.find_element(By.CLASS_NAME, "css-1orxpag").text.strip()
                price = "Ksh {}".format(price.split('\n')[0])

                # Extract product link
                link = element.find_element(By.TAG_NAME, "a").get_attribute("href")

                products.append((product, category, price, link))
        

    return pd.DataFrame(products, columns=['Product', 'Category',  'Price', 'Link'])

import csv
def extract_carrefour_data(driver, category_dict, csv_file_path):
    with open(csv_file_path, 'w', newline='', encoding='utf-8') as csvfile:
        fieldnames = ['Product', 'Category', 'Price', 'Link']
        writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
        writer.writeheader()

        for key, value in category_dict.items():
            my_logger.info(value)
            url = key
            category = value
            driver.get(url)

            try:
                scroll_to_end(driver)
                scroll_to_top(driver)
                scroll_to_bottom(driver)

            except Exception as e:
                my_logger.info(f"Exception: {str(e)}")

            product_rows = driver.find_elements(By.CLASS_NAME, "css-5kig18")

            for row in product_rows:
                product_elements = row.find_elements(By.CLASS_NAME, "css-b9nx4o")
                for element in product_elements:
                    # Extract product name
                    product = element.find_element(By.CLASS_NAME, "css-tuzc44").text.strip()

                    # Extract product price
                    price = element.find_element(By.CLASS_NAME, "css-1orxpag").text.strip()
                    price = "Ksh {}".format(price.split('\n')[0])

                    # Extract product link
                    link = element.find_element(By.TAG_NAME, "a").get_attribute("href")

                    writer.writerow({'Product': product, 'Category': category, 'Price': price, 'Link': link})
            products = pd.read_csv(csv_file_path)
            my_logger.info(f"On {category} with :{len(products)} total")
        
    products = pd.read_csv(csv_file_path)
    return products
     